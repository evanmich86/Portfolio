drop table phone_number;

drop table job_history;

drop table paid_by;

drop table job_listing;

drop table company;

drop table naics;

drop table course_knowledge;

drop table job_skill;

drop table person_skill;

drop table job;

drop table job_category;

drop table soc;

drop table knowledge_skill;

drop table career_cluster;

drop table career_tier;

drop table nwcet;

drop table takes;

drop table person;

drop table section;

drop table course;