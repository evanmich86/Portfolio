# workforce-management
A program that interfaces with a database that supports workforce management and career planning.

This project completes the (8) Development Tasks that were assigned in docs/DB-Instructions. 
The bulk of this project consisted of (27) queries found in sql/master_queries. 
