tables.sql contains the table builds.
you can make your own dummy data.

dist/4125Project.jar is the executable.

queries.sql contain all questions and queries for reference.